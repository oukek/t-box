import type { ApplicationContext, AppPlatform, AppRelease, MarketEntry, RuntimeDescriptor } from '@t-box/app-contracts'
import { validateRelease } from '@t-box/app-contracts'
import { shallowReactive } from 'vue'
import { ErrorCode } from '../../error-codes'
import { deviceApplicationScope } from './deviceStorage'
import { resolveLocalLaunch } from './localLaunch'

export const bundledApplications = shallowReactive({ releases: [] as AppRelease[], error: '' })
export function parseBundledApplications(value: unknown): AppRelease[] {
  const index = value as { protocol?: unknown, applications?: AppRelease[] } | null
  if (!index || index.protocol !== 1 || !Array.isArray(index.applications) || !index.applications.length || index.applications.length > 64) {
    throw ErrorCode.INTERNAL_INVALID_NATIVE_BUNDLES()
  }
  const ids = new Set<string>()
  for (const release of index.applications) {
    validateRelease(release)
    if (release.kind !== 'system' || !release.defaultInstalled || release.runtime.type !== 'web' || !release.platforms.includes('android') || !release.platforms.includes('ios') || ids.has(release.appId)) {
      throw ErrorCode.INTERNAL_INVALID_NATIVE_BUNDLES()
    }
    const url = new URL(release.runtime.entryUrl)
    if (url.origin !== 'https://bundled.tbox.invalid' || url.pathname !== `/${release.appId}/${release.runtime.integrity.slice(7)}/`) {
      throw ErrorCode.INTERNAL_INVALID_NATIVE_BUNDLES()
    }
    ids.add(release.appId)
  }
  return index.applications
}
/** Only the signed native host loads this index; web/remote app manifests cannot enable guest access. */
export async function loadBundledApplications() {
  if (!window.Capacitor?.isNativePlatform?.() || import.meta.env.DEV) {
    return
  }
  try {
    const response = await fetch(new URL('tbox-bundled-applications.json', document.baseURI), { credentials: 'omit', signal: AbortSignal.timeout(4000) })
    if (!response.ok) {
      throw ErrorCode.INTERNAL_INVALID_NATIVE_BUNDLES()
    }
    bundledApplications.releases = parseBundledApplications(await response.json())
  } catch (error) {
    bundledApplications.error = error instanceof Error ? error.message : '内置应用准备失败'
  }
}
export function bundledEntries(userId?: string, entries: readonly MarketEntry[] = []): MarketEntry[] {
  return bundledApplications.releases.map((release) => ({
    release,
    installedRelease: release,
    localOnly: true,
    installation: { appId: release.appId, releaseId: release.releaseId, generation: 1, status: 'active', targetReleaseId: null, operationId: null, grants: [] },
    localBinding: {
      subject: deviceApplicationScope(release.appId, userId, entries.find((entry) => entry.release.appId === release.appId)?.localBinding?.subject),
      storage: release.permissions.includes('storage'),
    },
  }))
}
export function mergeBundledEntries(entries: readonly MarketEntry[], userId?: string) {
  return [...entries, ...bundledEntries(userId, entries).filter((fallback) => !entries.some((entry) => entry.release.appId === fallback.release.appId))]
}
export function bundledLaunch(appId: string, platform: AppPlatform, userId?: string, entries: readonly MarketEntry[] = []) {
  return resolveLocalLaunch(bundledEntries(userId, entries), appId, platform)
}
export function bundledContext(appId: string, expected: Pick<RuntimeDescriptor, 'releaseId' | 'generation' | 'subject'>, platform: AppPlatform): ApplicationContext | undefined {
  const entry = bundledEntries().find((entry) => entry.release.appId === appId && entry.release.releaseId === expected.releaseId)
  if (!entry || entry.installation?.generation !== expected.generation || !/^[a-f0-9]{64}$/.test(expected.subject)) {
    return
  }
  entry.localBinding!.subject = expected.subject
  return resolveLocalLaunch([entry], appId, platform)?.context
}
