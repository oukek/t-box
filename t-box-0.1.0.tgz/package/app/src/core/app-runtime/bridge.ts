import type {
  BridgeRequest,
  BridgeResponse,
  HostMethod,
  RuntimeDescriptor,
} from '@t-box/app-contracts'
import {
  APP_PROTOCOL,
  APP_SDK_VERSION,
  applicationPayloadLimit,
  createApplicationRequestId,
} from '@t-box/app-contracts'
import { AppSdkError, SdkErrorCode } from '@t-box/app-sdk'
import { ErrorCode } from '../../error-codes.js'
import { request } from '../network'
import { identity } from '../session'
import { bundledLaunch } from './bundled'
import { appCatalog } from './catalog'
import { resolveLocalLaunch } from './localLaunch'
import { createHostTransport } from './sdkHost'

export interface AppConnection {
  readonly appNavigation: boolean
  invoke(name: string, args: unknown): Promise<unknown>
  close(): void
  cancelInteractions(): void
  navigate(params: Record<string, string>): void
}
// Vite may replace the module while an iframe remains mounted. Keep its live channel
// available to the new tool dispatcher instead of creating a second empty registry.
const connections: Map<
  string,
  { promise: Promise<AppConnection>, close(): void }
> = import.meta.hot?.data.connections ?? new Map()
if (import.meta.hot) {
  import.meta.hot.data.connections = connections
}
export async function descriptor(appId: string, options: { online?: boolean } = {}) {
  const platform = window.Capacitor?.isNativePlatform?.()
    ? window.Capacitor.getPlatform?.()
    : 'web'
  const targetPlatform = platform === 'android' || platform === 'ios' ? platform : 'web'
  const baseline = !options.online ? bundledLaunch(appId, targetPlatform, identity.user?.id, appCatalog.entries)?.descriptor : undefined
  let local = !options.online ? resolveLocalLaunch(appCatalog.entries, appId, targetPlatform)?.descriptor : undefined
  if (baseline) {
    // Shipped tools open immediately. A different account-installed version is used only after its local files exist.
    const { AppResources } = await import('@t-box/capacitor-app-resources')
    const digest = local?.integrity?.slice(7)
    if (!local || !digest || /^0{64}$/.test(digest) || !(await AppResources.has({ appId, digest })).ready) {
      local = baseline
    }
  }
  const result = local
    ? { data: local }
    : await request<{ data: RuntimeDescriptor }>(
        `/applications/${encodeURIComponent(appId)}/runtime?platform=${platform || 'web'}`,
      )
  const entry = new URL(result.data.entryUrl)
  if (
    result.data.protocol !== APP_PROTOCOL ||
    result.data.appId !== appId ||
    entry.origin !== result.data.origin ||
    !['http:', 'https:'].includes(entry.protocol) ||
    entry.username ||
    entry.password
  ) {
    throw ErrorCode.INTERNAL_INVALID_APPLICATION_RUNTIME()
  }
  // Local Vite live reload follows the host's LAN address. Packaged production always uses the registered HTTPS origin.
  if (
    import.meta.env.DEV &&
      new URL(result.data.entryUrl).hostname === 'localhost'
  ) {
    const url = new URL(result.data.entryUrl)
    url.hostname = location.hostname
    result.data.entryUrl = url.href
    result.data.origin = url.origin
  }
  if (result.data.origin === location.origin) {
    throw ErrorCode.INTERNAL_APPLICATION_ORIGIN_REQUIRED()
  }
  return result.data
}
export function connectFrame(
  frame: HTMLIFrameElement,
  runtime: RuntimeDescriptor,
  params: Record<string, string>,
) {
  const channel = new MessageChannel()
  const nonce = createApplicationRequestId()
  const userId = identity.user?.id
  const pending = new Map<
    string,
    {
      resolve(v: unknown): void
      reject(e: Error): void
      timer: ReturnType<typeof setTimeout>
    }
  >()
  let closed = false
  let ready = false
  let resolveReady!: (connection: AppConnection) => void
  let rejectReady!: (error: Error) => void
  const promise = new Promise<AppConnection>((resolve, reject) => {
    resolveReady = resolve
    rejectReady = reject
  })
  // A failed load can reject before an AI tool waits for it. The page still displays the actual error.
  void promise.catch(() => {})
  const currentParams = { ...params }
  const transport = createHostTransport({
    appId: runtime.appId,
    expected: runtime,
    params: currentParams,
  })
  const stopEvents = transport.listen((event) => {
    if (!closed) {
      channel.port1.postMessage(event)
    }
    if (event.name === 'runtime.closed') {
      close('应用会话已结束')
    }
  })
  const timer = setTimeout(close, 15000, '应用连接超时：页面未完成 SDK 初始化，请检查应用控制台和资源是否正常加载')
  function close(reason = '应用已关闭') {
    if (closed) {
      return
    }
    closed = true
    clearTimeout(timer)
    channel.port1.postMessage({
      type: 'event',
      name: 'runtime.closed',
      data: { code: 'APP_CLOSED', message: reason },
    })
    stopEvents()
    transport.close()
    channel.port1.close()
    channel.port2.close()
    rejectReady(ErrorCode.INTERNAL_APPLICATION_EXECUTION_FAILED(reason))
    for (const p of pending.values()) {
      clearTimeout(p.timer)
      p.reject(ErrorCode.INTERNAL_APPLICATION_EXECUTION_FAILED(reason))
    }
    pending.clear()
    if (connections.get(runtime.appId)?.promise === promise) {
      connections.delete(runtime.appId)
    }
  }
  const current = async () => {
    if (closed || identity.user?.id !== userId) {
      throw ErrorCode.INTERNAL_APPLICATION_SESSION_ENDED()
    }
    if (!navigator.onLine) {
      throw SdkErrorCode.NETWORK_REQUIRED()
    }
    const latest = await descriptor(runtime.appId, { online: true })
    if (closed || identity.user?.id !== userId) {
      throw ErrorCode.INTERNAL_APPLICATION_SESSION_ENDED()
    }
    if (
      latest.releaseId !== runtime.releaseId ||
      latest.generation !== runtime.generation
    ) {
      close('应用安装状态已改变')
      throw ErrorCode.INTERNAL_APPLICATION_REOPEN_REQUIRED()
    }
  }
  channel.port1.onmessage = async (event: MessageEvent) => {
    const data = event.data
    if (closed || !data || identity.user?.id !== userId) {
      return
    }
    if (data.type === 'ready') {
      if (
        ready ||
        data.nonce !== nonce ||
        (data.appNavigation !== undefined &&
          typeof data.appNavigation !== 'boolean') ||
          !Array.isArray(data.tools) ||
          JSON.stringify([...data.tools].sort()) !==
          JSON.stringify([...runtime.clientTools].sort())
      ) {
        close('应用工具声明不匹配')
        return
      }
      ready = true
      clearTimeout(timer)
      resolveReady({
        appNavigation: data.appNavigation === true,
        close: () => close(),
        cancelInteractions: () =>
          channel.port1.postMessage({
            type: 'event',
            name: 'runtime.interactions.cancelled',
            data: {},
          }),
        navigate: (params) => {
          for (const key of Object.keys(currentParams)) {
            delete currentParams[key]
          }
          Object.assign(currentParams, params)
          channel.port1.postMessage({
            type: 'event',
            name: 'runtime.navigation',
            data: params,
          })
        },
        invoke: async (name, args) => {
          await current()
          if (!runtime.clientTools.includes(name)) {
            throw ErrorCode.INTERNAL_APPLICATION_TOOL_FORBIDDEN()
          }
          return new Promise((resolve, reject) => {
            const id = createApplicationRequestId()
            const timeout = setTimeout(() => {
              pending.delete(id)
              reject(ErrorCode.INTERNAL_APPLICATION_TOOL_TIMEOUT())
            }, 300_000)
            pending.set(id, { resolve, reject, timer: timeout })
            channel.port1.postMessage({
              type: 'request',
              id,
              method: name,
              args,
            })
          })
        },
      })
      return
    }
    if (typeof data.id !== 'string' || data.id.length > 80) {
      return
    }
    if (!ready && data.type !== 'request') {
      return
    }
    if (data.type === 'response') {
      const p = pending.get(data.id)
      if (!p) {
        return
      }
      clearTimeout(p.timer)
      pending.delete(data.id)
      try {
        await current()
      } catch (e) {
        p.reject(
          e instanceof Error
            ? e
            : ErrorCode.INTERNAL_APPLICATION_AUTHORIZATION_EXPIRED(),
        )
        return
      }
      data.ok === true
        ? p.resolve(data.data)
        : p.reject(
            ErrorCode.INTERNAL_APPLICATION_EXECUTION_FAILED(
              typeof data.error === 'string'
                ? data.error.slice(0, 300)
                : '应用执行失败',
            ),
          )
      return
    }
    if (data.type !== 'request') {
      return
    }
    const r = data as BridgeRequest
    try {
      if (JSON.stringify(r.args).length > applicationPayloadLimit(r.method)) {
        throw ErrorCode.INTERNAL_APPLICATION_REQUEST_TOO_LARGE()
      }
      const value = await transport.call(r.method as HostMethod, r.args, {
        idempotencyKey: r.options?.idempotencyKey ?? r.id,
        timeoutMs: r.options?.timeoutMs,
      })
      if (!closed) {
        channel.port1.postMessage({
          type: 'response',
          id: r.id,
          ok: true,
          data: value,
        } satisfies BridgeResponse)
      }
    } catch (e) {
      if (!closed) {
        channel.port1.postMessage({
          type: 'response',
          id: r.id,
          ok: false,
          error: e instanceof Error ? e.message : '请求失败',
          failure: {
            code: AppSdkError.from(e).code,
            message: AppSdkError.from(e).message,
            status: AppSdkError.from(e).status,
          },
        } satisfies BridgeResponse)
      }
    }
  }
  connections.get(runtime.appId)?.close()
  connections.set(runtime.appId, { promise, close: () => close() })
  frame.contentWindow!.postMessage(
    {
      type: 'tbox.connect',
      protocol: APP_PROTOCOL,
      sdkVersion: APP_SDK_VERSION,
      nonce,
      context: {
        appId: runtime.appId,
        releaseId: runtime.releaseId,
        generation: runtime.generation,
        subject: runtime.subject,
        params: { ...params },
      },
    },
    runtime.origin,
    [channel.port2],
  )
  return { promise, close: () => close() }
}
export async function invokeApplicationTool(
  value: unknown,
  open: (args: unknown) => Promise<unknown>,
) {
  if (!value || typeof value !== 'object') {
    throw ErrorCode.INTERNAL_INVALID_APPLICATION_TOOL_ARGUMENTS()
  }
  const a = value as {
    appId: string
    releaseId: string
    generation: number
    tool: string
    arguments: unknown
  }
  if (
    Object.keys(a).some(
      (k) =>
        !['appId', 'releaseId', 'generation', 'tool', 'arguments'].includes(k),
    ) ||
    typeof a.appId !== 'string' ||
    typeof a.tool !== 'string'
  ) {
    throw ErrorCode.INTERNAL_INVALID_APPLICATION_TOOL_ARGUMENTS()
  }
  const runtime = await descriptor(a.appId, { online: true })
  if (
    runtime.releaseId !== a.releaseId ||
    runtime.generation !== a.generation ||
    !runtime.clientTools.includes(a.tool)
  ) {
    throw ErrorCode.INTERNAL_APPLICATION_TOOL_AUTHORIZATION_EXPIRED()
  }
  await open({ appId: a.appId })
  // Rendering creates the iframe before its load callback establishes the channel.
  const started = Date.now()
  while (!connections.has(a.appId) && Date.now() - started < 15000) {
    await new Promise((r) => setTimeout(r, 30))
  }
  const connection = connections.get(a.appId)
  if (!connection) {
    throw ErrorCode.INTERNAL_APPLICATION_NOT_OPEN()
  }
  return (await connection.promise).invoke(a.tool, a.arguments)
}
export function closeApplicationRuntimes() {
  for (const connection of connections.values()) {
    connection.close()
  }
  connections.clear()
}
/** Trusted application adapters delegate interaction UI into their isolated application. */
export async function invokeDeclaredApplicationTool(
  appId: string,
  tool: string,
  args: unknown,
  open: (value: unknown) => Promise<unknown>,
) {
  const runtime = await descriptor(appId, { online: true })
  return invokeApplicationTool(
    {
      appId,
      releaseId: runtime.releaseId,
      generation: runtime.generation,
      tool,
      arguments: args,
    },
    open,
  )
}
export function cancelApplicationInteractions(appId: string) {
  void connections
    .get(appId)
    ?.promise
    .then((connection) => connection.cancelInteractions())
    .catch(() => {})
}
