# 价格、用户余额与支付

价格存 MySQL，由后台「模型」弹窗管理；普通用户接口不返回模型、服务商、API Key 或上游响应 ID；费用说明仅返回当前可用服务的输入/输出及图片售价。后台「用户与余额」管理普通用户的扣费方式、余额赠送及费用核对，「支付订单」查看充值订单并查询渠道结果。「管理员」仍是独立的后台登录账户。

首次部署运行 `pnpm db:init`，旧开发库按 [数据库初始化](database-initialization.md) 处理。新模型的三个价格默认是 0，新用户余额是 0、模式是 `charge`，不会因此自动开始收费。需要先配置价格，再通过受审计的余额赠送或后续支付充值提供余额。

## 用户页面与充值配置

“AI → AI 中心 → AI 费用说明”读取 `/wallet/pricing`，展示当前启用会话和图片服务的价格及计费方式，不暴露模型身份。没有可用服务时显示尚未开放，不用占位价格。余额页仅显示余额与使用、流水、订单记录；点击充值进入独立 `/ai/recharge` 页面。iOS 原生壳及未开放支付渠道的提示、禁用支付按钮均位于充值页，余额页仍可查看记录并进入充值页。

后台“充值配置”管理最多 12 个充值套餐；每个套餐有金额、独立赠送金额及上架开关，金额不重复。前端从后端读取已上架套餐，不内置金额或优惠。首次初始化的档位为 10、30、50、100、200、500 元，默认不赠送。

自定义充值开关存于同一配置，**默认关闭**。关闭时前端不显示输入框，后端创建新订单也只接受已上架套餐的金额，拒绝直接提交任意金额。开启后允许 1–10000 元、最多 2 位小数的自定义金额。金额恰好匹配已上架套餐时，使用该套餐的独立优惠；其他自定义金额才使用单独的满赠规则，最多 20 档，仅取最高达标档，不叠加。套餐与自定义规则可以同时保留，关闭自定义充值不删除其规则。后台用配置 revision 拒绝覆盖并发编辑；满赠按整数分计算，前端不能指定实际赠送。套餐下架和关闭自定义充值不影响已创建订单的原优惠及支付恢复。

创建订单时由服务端读取规则并固定 `payment_orders.bonus_cents`；该字段默认值为 0；旧开发库不会通过首次初始化自动转换订单。支付渠道仅核验实付 `amount_cents`，不会把赠送金额算作实际收款。验签/核对成功后，同一事务分别记入实付 recharge 流水和满赠 grant 流水，重复通知不重复入账。订单 API 返回 `amount`、`bonusAmount`、`creditedAmount`，规则改动不影响已有订单。下单返回的赠送若与页面预览不同，会先显示实际到账金额，用户确认后才能继续支付同一订单。公众号授权、H5 回跳及原生冷启动恢复均进入充值页；旧余额页带 paymentOrder 参数的回跳仍兼容。

## 价格规则

- 币种固定 CNY。输入、输出单价分别是 **元 / 百万 token**，支持 6 位小数。图片价格是 **元 / 张**，当前生成与编辑统一收费，每次一张 1024 × 1024 图片。
- 这里配置的是用户售价，不是自动同步的服务商成本。后台连接测试也不扣普通用户余额。
- 使用服务商的 Responses `usage.input_tokens` / `output_tokens`，或 Chat Completions `usage.prompt_tokens` / `completion_tokens`，统一记录与结算。缓存输入目前按普通输入价计算；输出 token 已包含服务商计入的思考输出，不再另外加思考 token。参考 [OpenAI token 统计说明](https://developers.openai.com/api/docs/guides/token-counting)。看图请求仍通过普通会话的实际 input usage 计费。
- 每个模型调用独立计费，包括工具调用前后的轮次及专业 Agent 的模型调用。应用内记账、导航、权限验证等工具本身不另收费；图片工具走独立按张计费。
- 金额用 `BigInt` 整数微元计算，数据库 `BIGINT` 保存余额、费用和流水。1 元 = 1,000,000 微元。每次模型调用合并输入与输出费用后，向上取整到 1 微元；不使用浮点金额，也不向上取整到 1 分。充值渠道使用整数分。
- 普通会话模型配置及价格在任务开始时取得快照，多轮任务保持同一配置；图片模型在该任务第一次调用图片工具时取得快照。价格调整不改变已经发生的费用。
- 用户扣费模式在每次调用预留时取得快照。`record_only` 保留实际用量和计算费用，实扣为 0，无需余额。改模式不会改变已经发起的调用。
- 标题生成不预留用户余额、不扣费；平台记录实际用量和成本并纳入预算，费用审计的 purpose 为 title。

## 模块与调用边界

```text
AI 编排 → ChatProvider → MeteredChatProvider → createConversationProvider → Responses / Chat Completions
                              ↓
                        BillingService → MySQL
图片应用 → ImageTools ──────────┘

用户 REST / 后台 REST → PaymentService → PaymentGateway
                             ↓
                       BillingService → 钱包流水
```

`api/src/billing/money.ts` 处理精确金额，`service.ts` 处理钱包、预留、结算和审计，`provider.ts` 装饰普通会话 Provider。通用编排只传递用户、任务及调用标识，不包含价格或支付业务。`server.ts` 是装配入口，将同一个计费服务注入数据库 Provider 与图片服务。测试 Provider 可以独立运行，不请求真实模型。

`billing_wallets` 保存余额、预留及模式；`billing_usage` 保存调用时价格、模式、实际用量和结算状态；`billing_entries` 保存不可由用户修改的余额流水；`billing_audit` 保存管理员的模式修改、预留解除和人工核对。支付订单独立存 `payment_orders`。价格关联仅保留配置 ID，不用外键阻止管理员删除已停用模型；历史收费由价格快照解释。

## 余额预留与不确定结果

调用前预留余额。会话的预留预算使用序列化输入、工具定义和指令的 UTF-8 字节数加固定余量，以及本轮 2048 输出 token 上限；这是**保守的入场预算，不是精确 token 统计，也不用于最终收费**。图片以固定余量估算，base64 字节不作为文本 token；包含附件的请求仍可能预留较多，结束后返还未使用的预留。为兼容已有 Responses 服务商，不强制额外调用 input-token counting 接口。

所有同账户资金操作先取得钱包排他锁，再处理本条费用或流水。可用余额 = 余额 − 预留。余额不足返回 `402 BALANCE_INSUFFICIENT`，不发起本次模型/图片请求。真实用量回来后，在同一事务里解除预留、扣余额、记录流水。结算 ID 和流水引用唯一；重复结算不重复扣款，用量不一致的重放返回冲突。

- 已完成或 incomplete/failed 响应如果提供有效 usage，按实际消耗结算；模型没有完成回答不代表服务商没有消耗。
- 没有 usage、断线或未知外部结果，记录变成 `review`，保留预留，不猜用量、不自动重复调用。完整响应仅缺 usage 时，免费模型或仅记录用户仍可正常使用真实输出和工具，保留待核对记录，不影响余额；实际收费调用则停止后续执行，等待核对。进程退出遗留的预留超过 10 分钟后也转待核对。图片只有生成结果有效并保存到用户资源后才结算。
- 如果兼容服务商实际用量超出预算，但余额足够，可按实际金额结算；余额不足时保留实际用量待核对，不产生负余额、不偷偷部分扣款。
- 后台可以「结算已知用量」，沿用原价格和扣费模式，需填写原因且余额充足。用量未知时不能输入一个估算金额强扣，只能「解除预留」，保留记录并放弃本次用户扣费。
- 这里保证本条费用的幂等结算，不承诺跨网络的模型请求 exactly-once。SDK 自动重试关闭；用户主动继续中断任务可能产生新的真实模型调用及费用。应先核对待核对记录。

用户端「AI → AI 中心 → 我的余额」展示可用余额、预留、使用明细、资金流水与充值订单。费用、用户、订单列表目前分别提供最近 100 / 200 / 100 条，用户列表支持服务端搜索任意已注册账号，避免无界读取；完整历史仍在数据库，后续规模扩大可接分页和导出。用户明细只显示通用服务名称，不显示具体模型。

## 微信支付实现

`payments/WechatGateway` 实现普通商户 API v3 Native、H5、JSAPI、APP 下单、查单、关闭、原始通知验签与 AES-256-GCM 解密。固定调用 api.mch.weixin.qq.com，签名和验签使用 Node crypto 的 RSA-SHA256；拒绝重定向、未知公钥、过期签名、修改后的原始通知及签名探测流量。没有客户端或后台“标记支付成功”接口。

微信官方的 [服务端 SDK 清单](https://pay.wechatpay.cn/doc/v3/partner/4012083109) 包含 Java、PHP、Go；Node 社区库属于非官方库。本项目按官方 API v3 协议实现独立适配器，便于后续更换 SDK，不混入钱包或 AI 业务。二维码使用 qrcode 算法库在本地生成，自有弹窗组件展示，不发送到第三方二维码服务。

充值金额 1–10000 元，最多 2 位小数；订单 30 分钟有效。创建重试保持同一个 Idempotency-Key。同金额恢复原订单，不同金额返回 409；同账户最多 10 个未过期待支付订单。UUID 去掉连字符作为微信商户订单号，满足最多 32 字符，回调再恢复本地 UUID。第一次发起支付锁定渠道模式，后续不能把同一单从 Native 换成 H5；可在原浏览器继续或关闭后创建新单。

| 浏览器           | 支付路径                                                      | 实现                                                                |
| ---------------- | ------------------------------------------------------------- | ------------------------------------------------------------------- |
| PC               | [Native](https://pay.wechatpay.cn/doc/v3/merchant/4012791877) | 自有弹窗显示二维码，每 3 秒读取本地订单、间隔约 15 秒请求服务端核对 |
| 微信外移动浏览器 | [H5](https://pay.wechatpay.cn/doc/v3/merchant/4012791834)     | 服务端提交真实终端 IP，跳转微信 H5 链接，返回余额页面后核对订单     |
| 微信内网页       | [JSAPI](https://pay.wechatpay.cn/doc/v3/merchant/4012791856)  | snsapi_base 网页授权获取 openid，再以 WeixinJSBridge 调起付款       |

前端 JSAPI 的 ok 结果、返回页面参数都不能直接入账。只有通过可信查单 / 通知并核对商户、AppID、SUCCESS、金额、币种、订单时间和唯一微信流水后，才在一个本地事务中修改 paid、增加钱包余额、写流水。并发通知和反复查单只入账一次；本地关闭后到达的真实成功通知仍可以入账。用户查单按订单在数据库内限频，5 秒内不会重复请求微信，后台主动核对独立。

公众号授权 state 是服务端生成的随机值，只保存哈希，绑定当前登录用户、订单和商户配置，10 分钟有效且单次使用。获取的 openid 加密保存于 payment_wechat_users；不接受前端自行填 openid，不返回 OAuth access_token，也不交给 AI。返回地址仅从后台固定网站配置生成，不能由客户端控制跳转域名。

## 后台配置和部署

进入后台「支付订单 → 微信支付配置」填写：服务号 AppID、商户号、商户 API 证书序列号、商户私钥 PEM、32 字节 API v3 密钥、微信支付公钥 ID 和 PEM（或平台证书序列号与证书 PEM）、服务号 AppSecret、API 公网地址、前端网站根地址和商品描述，选择已开通的渠道并开放充值。密钥留空保留已配置值；修改商户 / AppID 要重新填对应密钥；所有密钥加密入库，GET 只返回是否已配置，沿用 api/.secrets/provider.key。数据库和加密主密钥必须一起备份。

服务号 AppID/AppSecret 来自微信公众平台；商户号、API 证书及 API v3 密钥来自微信支付商户平台。这些凭据不能互相替代。当前 AppSecret 只接入支付订单的网页授权，未接入服务号消息发送；消息 Token、EncodingAESKey、模板 ID 没有项目配置入口。完整字段来源和消息能力边界见 [首次部署：微信配置](first-deployment.md#6-微信配置)。

支付配置每次保存产生不可变版本，记录管理员；订单绑定创建时的版本，防止把旧商户订单按新商户核对。证书、公钥、API v3 密钥和 AppSecret 的轮换是商户 / 公众号层面的变化：旧订单保留商户和 AppID，但请求使用同一商户的最新签名凭据，通知接受已配置可信公钥以及同一商户的新旧 API v3 解密密钥。旧配置不自动删除；未知新公钥不会自动信任，需管理员按微信商户平台更新。停止开放只影响新订单，旧订单通知和核对继续有效。

微信侧还需要：

1. 商户号绑定服务号 AppID，并开通 Native、JSAPI；微信外网页另需申请 H5 支付，服务号支付权限不能代替 H5 权限。
2. 商户平台配置 H5 支付域名、JSAPI 支付授权目录；公众号平台配置网页授权域名。授权回调在 API 域名，支付网页在前端域名，分别检查，不要只配置其中一个。
3. 使用公网 HTTPS。填入 API 根地址后，通知为 `/api/v1/payments/webhooks/wechat`，授权回调为 `/api/v1/payments/wechat/oauth/callback`。通知地址不带查询参数，不重定向；反向代理保留 Wechatpay-* 请求头和原始 JSON 字节。
4. 默认信任本机回环地址的 Nginx，无须额外填写代理配置；其他拓扑才需设置 `TRUSTED_PROXIES` 为实际代理 IP / CIDR，不能信任任意来源。API 以 Fastify request.ip 获取终端 IP，只接受可信代理的 X-Forwarded-For。前端填写真实 API 地址；跨域默认开放。
5. 完成配置后，在真实 PC、微信内浏览器、微信外浏览器分别做小额下单 / 取消 / 成功支付与余额核对，验证域名权限和服务号绑定。本地 localhost 不能代替这些微信侧联调条件。

原生 Capacitor 微信 SDK 支付已接入，详见 [原生支付配置与真机联调](wechat-native-payments.md)。已实现全额原路退款、赠送额度回收和每日商户交易账单对账，见下文。部分退款、提现与发票尚未实现。资金流水不可通过删除或修改 paid 模拟退款。

## REST 接口

普通用户 Bearer 认证：

| 方法         | 路径（`/api/v1`）                 | 用途                                            |
| ------------ | --------------------------------- | ----------------------------------------------- |
| GET          | `/wallet`                         | 余额、预留、可用额、模式                        |
| GET          | `/wallet/pricing`                 | 当前服务售价及计费单位，隐藏模型与服务商        |
| GET          | `/payments/recharge-options`      | 已上架套餐、自定义充值开关及规则                    |
| GET          | `/wallet/usage`                   | 使用费用记录，不返回模型                        |
| GET          | `/wallet/entries`                 | 余额变动                                        |
| GET          | `/payments/capabilities`          | 在线充值是否启用                                |
| GET / POST   | `/payments/orders`                | 订单列表 / 创建订单（amount 字符串、幂等键）    |
| GET / DELETE | `/payments/orders/:id`            | 自己的订单 / 先关闭渠道订单                     |
| POST         | `/payments/orders/:id/intent`     | `{mode:"native" / "h5" / "jsapi"}` 获取支付方式 |
| POST         | `/payments/orders/:id/refresh`    | 只核对自己的订单；数据库节流                    |
| GET          | `/payments/wechat/oauth/callback` | 微信网页授权回调，单次 state                    |
| POST         | `/payments/webhooks/wechat`       | 仅接收适配器验签的原始通知                      |

后台 Cookie 会话及 `X-Admin-Request: 1`：

- `GET /admin/billing/users`、`GET /admin/billing/users/:id/usage`、`GET /admin/billing/users/:id/entries`
- `PATCH /admin/billing/users/:id`：`{mode, reason}`
- `POST /admin/billing/users/:id/grants`：`{amount, reason}`、稳定 `Idempotency-Key`
- `POST /admin/billing/users/:id/usage/:usageId/release`、`.../settle`：`{reason}`
- `GET / PATCH /admin/payments/recharge-options`：读取 / 保存档位及满赠，更新携带当前 revision
- `GET / PATCH /admin/payments/wechat`：读取脱敏配置 / 加密保存新版本
- `GET /admin/payments/orders`、`GET /admin/payments/capabilities`
- `POST /admin/payments/orders/:id/reconcile`：仅查询渠道并接受可信成功结果

## 验证

`pnpm test:billing` 使用真实 MySQL 临时用户、本地图片接口和仅测试代码中的可信支付适配器；覆盖精确收费、并发预留、重复结算、模式快照、标题免费、缺失用量、未完成响应、按张收费、伪造/重复通知、金额及归属校验、重复渠道流水、关闭竞态、原始字节验签边界及用户模型信息隔离。测试结束清除自己的用户、资源及管理员，不调用真实模型或微信。

`pnpm test:wechat` 使用真实临时 MySQL 用户、隔离配置指针和本地 RSA / AES 签名渠道，覆盖三个下单渠道、通知 / 响应验签、幂等入账、OAuth、JSAPI 签名、停用与密钥轮换。后台配置、二维码和移动 JSAPI 另以浏览器模拟渠道验证。未使用真实商户收款。消息 token 与上下文策略详见 [上下文与用量](ai-context-and-usage.md)。

退款、赠送回收、原路资金确认和每日商户账单核对的实现与联调边界见 [退款与渠道对账](payment-refunds-and-reconciliation.md)。成本预算、共享并发与免扣费标题的审计见 [AI 成本控制](ai-cost-controls.md)。
